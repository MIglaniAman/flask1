from flask import Flask, render_template, request
from werkzeug.utils import secure_filename
from werkzeug.datastructures import FileStorage
import os

app = Flask(__name__)

app.config['UPLOAD_FOLDER'] = "C:/Users/HP/Desktop/test"


@app.route('/')
def index():
    return render_template('upload.html')


@app.route('/upload', methods=['GET', 'POST'])
def upload():
    if request.method == 'POST':
        f1 = request.files['media1']
        print(f1)
        f2 = request.files['media2']
        print(f2)
        f3 = request.files['media3']
        print(f3)

        if f1:
            filename1 = secure_filename(f1.filename)
            f1.save(os.path.join(app.config['UPLOAD_FOLDER'], filename1))

        if f2:
            filename2 = secure_filename(f2.filename)
            f2.save(os.path.join(app.config['UPLOAD_FOLDER'], filename2))

        if f3:
            filename3 = secure_filename(f3.filename)
            f3.save(os.path.join(app.config['UPLOAD_FOLDER'], filename3))

        return render_template('upload.html')


if __name__ == '__main__':
    app.run(debug=True)
